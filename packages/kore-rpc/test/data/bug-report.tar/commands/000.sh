#!/usr/bin/env bash
set -euxo pipefail
kore-rpc definition.kore --module IMP
